To compile the project, 
please execute the make run command - this will create the 
necessary folder for the output for the simulation and which will 
also hold the visualization of the data once the graph is created

- the program can be built and run by executing: make run 
- make graph : will plot the csv information using python and output it to the /out folder